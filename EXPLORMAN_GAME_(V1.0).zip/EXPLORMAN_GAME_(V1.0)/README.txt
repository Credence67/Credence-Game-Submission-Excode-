-----------------------------------------------------------------------------------------
Password : EPDMAN290 [THIS IS IMPORTANT]
-----------------------------------------------------------------------------------------
___________________________________________________________
\___\  \__\   \________\   \___\      \___\      \____________\
\|  |  |  |   \|       |  \|   |     \|   |      \|   ______  |
\|  |  |  |   \|   ____|  \|   |     \|   |      \|   |    |  |
\|  |__|  |   \|  |____   \|   |     \|   |      \|   |    |  |
\|   __   |   \|   ____|  \|   |     \|   |      \|   |    |  |
\|  |  |  |   \|  |____   \|   |___\ \|   |___\  \|   |    |  |
\|  |  |  |   \|       |  \|       | \|       |  \|   |____|  |
\|__|  |__|   \|_______|  \|_______| \|_______|  \|___________|


Welcome to EXPLORMAN.

If you are reading this, then I would like to congratulate you on your new position. Welcome to your new job, Manager. The International Guilds and Exploration Teams (IGET) executives have decided that you are most fitted for the job.

I am EXPLORMAN and I will be the machine to help you with your job. If you have not been briefed or you just want a refresher, allow me to explain. Your job is to manage the expeditions made into the 'infinite' dungeon. You will be able to give commands, monitor and log expeditions using this software.

**Instructions**
-----------------------------------------------------------------------------------------
If you are using a Mac software:
- Ensure that python3 is installed in your software
- Run the Mac Unix Executable file (EXPLORMAN_GAME_(MAC)) via terminal by double-clicking
-----------------------------------------------------------------------------------------
If you are using a Windows/ Linux software:
-Ensure python3 is installed
-Open your terminal equivalent
-Type: python EXPLORMAN_GAME.py
-Press Enter/Return to run.
-----------------------------------------------------------------------------------------


**How to play EXPLORMAN**

1. Log in using the password above
2. Allocate your desired stats in DEX, STR and AGI to find your perfect dungeon crawler (Total must be equal to 20)
3. Using the system to command dungeon crawlers to choose amongst the different strategies:
-Aggressive (More likely to attack)
-Passive (More likely to defend)
-Flexible (50/50)
4. Upgrade the adventurers stats at the end of the round.
5. See how far the specime- I mean adventurer survives.

There is no turning back when you decide to enter the infinite dungeon. Good luck to all and good riddance.

-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------